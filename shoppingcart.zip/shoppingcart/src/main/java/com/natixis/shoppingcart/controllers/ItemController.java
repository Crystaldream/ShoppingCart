package com.natixis.shoppingcart.controllers;

import com.natixis.shoppingcart.models.Item;
import com.natixis.shoppingcart.repository.ItemRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/items")
public class ItemController {

	private ItemRepository itemRepository;

	public ItemController(ItemRepository itemRepository) {
		this.itemRepository = itemRepository;
	}

	@GetMapping("/items/all")
	public List<Item> getAllItems() {
		return this.itemRepository.findAll();
	}

	@PutMapping
	public void insert(@RequestBody Item item) {
		this.itemRepository.insert(item);
	}

	@PostMapping
	public void update(@RequestBody Item item) {
		this.itemRepository.save(item);
	}

	@DeleteMapping("/items/{id}")
	public void delete(@PathVariable("id") String id) {
		this.itemRepository.deleteById(id);
	}

}
