package com.natixis.shoppingcart.models;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@ToString
@Setter
@Getter
@Document(collection = "Items")
public class Item {

	@Id
	private String id;

	@NotBlank
	@Size(max = 100)
	@Indexed(unique = true)
	private String nome;

	private String valor;

	public Item() {

	}

	public Item(String id, String nome, String valor) {
		this.id = id;
		this.nome = nome;
		this.valor = valor;
	}

}