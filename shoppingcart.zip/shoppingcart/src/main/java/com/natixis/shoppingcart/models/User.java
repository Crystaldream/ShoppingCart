package com.natixis.shoppingcart.models;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@ToString
@Setter
@Getter
@Document(collection = "Users")
public class User {

	@Id
	private String id;

	@NotBlank
	@Size(max = 300)
	@Indexed(unique = true)
	private String nome;

	private String mail;

	private List<Item> cart = new ArrayList<>();

	public User() {

	}

	public User(String id, String nome, String mail) {
		this.id = id;
		this.nome = nome;
		this.mail = mail;
	}

	public void fecharCompras() {

		int cnt = 0;
		int total = 0;

		List<String> names = new ArrayList<>();

		if (!cart.isEmpty()) {

			for (Item c : cart) {
				names.add(c.getNome());
			}

			String[] arr = names.toArray(new String[0]);
			Arrays.sort(arr);

			int j = 0;

			while (cnt < cart.size()) {

				for (Item item : cart) {

					if (item.getNome().equals(arr[j])) {
						System.out.println("Nome: " + item.getNome() + " Valor: " + item.getValor());
						j++;
						total += Integer.parseInt(item.getValor());
					}

				}

				cnt++;

			}

		}

		if (total == 0) {
			System.out.println("Carrinho Vazio");
		} else {
			System.out.println("Total: " + total);
		}

	}

}