export class Item {
    id: number;
    nome: string;
    valor: string;
}