export class User {
    id: number;
    nome: string;
    mail: string;
}